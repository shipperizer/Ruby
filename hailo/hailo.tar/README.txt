Develop a program that, given a series of points (latitude,longitude,timestamp) for a cab journey from A-B, will disregard potentially erroneous points.

Your answer must be returned as a single file which can be run on the command line.

The attached dataset is provided as an example, with a png of the 'cleaned' route as a guide. 